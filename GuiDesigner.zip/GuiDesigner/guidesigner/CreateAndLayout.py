def main(parent):

	LabelFrame('Options',text="""Options""",link="guidesigner/Options.py")
	pack(fill=X,anchor=N)

	Frame('LayoutShort',link="guidesigner/LayoutShort.py")
	pack(side='bottom',anchor='n',fill='x')
