import DynTkInter as tk
tk.Tk().mainloop('guidesigner/Guidesigner.py')
