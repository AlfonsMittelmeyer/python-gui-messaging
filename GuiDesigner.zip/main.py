from DynTkInter import *


 
Tk()

gui()

mainloop()
